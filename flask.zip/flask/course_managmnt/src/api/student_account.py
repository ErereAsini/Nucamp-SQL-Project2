from flask import Blueprint

bp = Blueprint('student_account', __name__, url_prefix='/student_account')