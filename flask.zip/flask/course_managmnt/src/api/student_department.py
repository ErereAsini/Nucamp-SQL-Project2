from flask import Blueprint

bp = Blueprint('student_department', __name__, url_prefix='/student_department')