from flask import Blueprint

bp = Blueprint('professor', __name__, url_prefix='/professor')